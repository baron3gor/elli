<?php if ( ! defined( 'ABSPATH' ) ) die( 'Direct access forbidden.' );

/**
 * Creates widget with recent post thumbnail
 */

class Aletheme_Workinghours_Widget extends WP_Widget
{
    function __construct() {
        $widget_opt = array(
            'classname'     => 'ale_workinghours_widget',
            'description'   => 'A widget that displays working hours. (Monday/Tuesday/Wednesday/Thursday/Friday/Saturday/Sunday)'
        );
        
        parent::__construct('ale-workingshours', esc_html__('Elli Working Hours', 'elli'), $widget_opt);
    }
    
    function widget( $args, $instance ){
    	global $wp_query;

        echo ale_return( $args[ 'before_widget' ] );
        if ( !empty( $instance[ 'title' ] ) ) {

            echo ale_return( $args[ 'before_title' ] ) . apply_filters( 'widget_title', $instance[ 'title' ] ) . ale_return( $args[ 'after_title' ] );
        }

       
        $monday_hours        = '';
        $tuesday_hours       = '';
        $wednesday_hours     = '';
        $thursday_hours      = '';
        $friday_hours        = '';
        $saturday_hours      = '';
        $sunday_hours        = '';

        
        if(isset($instance['monday_hours'])){
            $monday_hours = $instance['monday_hours'];
        }
        if(isset($instance['tuesday_hours'])){
            $tuesday_hours = $instance['tuesday_hours'];
        }
        if(isset($instance['wednesday_hours'])){
            $wednesday_hours = $instance['wednesday_hours'];
        }
        if(isset($instance['thursday_hours'])){
            $thursday_hours = $instance['thursday_hours'];
        }
        if(isset($instance['friday_hours'])){
            $friday_hours = $instance['friday_hours'];
        }
        if(isset($instance['saturday_hours'])){
            $saturday_hours = $instance['saturday_hours'];
        }
        if(isset($instance['sunday_hours'])){
            $sunday_hours = $instance['sunday_hours'];
        }
        
        ?>
        <div class="openhours-widget">
            <?php if($monday_hours != ''): ?>
                <div class="hours-wrapper">
                    <span class="work-day"><?php echo esc_html('Monday') ?></span><span class="btm_line"></span><span class="work-hours"><?php echo esc_html($monday_hours) ?></span>
                </div>
            <?php endif; ?>

            <?php if($tuesday_hours != ''): ?>
                <div class="hours-wrapper">
                    <span class="work-day"><?php echo esc_html('Tuesday') ?></span><span class="btm_line"></span><span class="work-hours"><?php echo esc_html($tuesday_hours) ?></span>
                </div>
            <?php endif; ?>

            <?php if($wednesday_hours != ''): ?>
                <div class="hours-wrapper">
                    <span class="work-day"><?php echo esc_html('Wednesday') ?></span><span class="btm_line"></span><span class="work-hours"><?php echo esc_html($wednesday_hours) ?></span>
                </div>
            <?php endif; ?>

            <?php if($thursday_hours != ''): ?>
                <div class="hours-wrapper">
                    <span class="work-day"><?php echo esc_html('Thursday') ?></span><span class="btm_line"></span><span class="work-hours"><?php echo esc_html($thursday_hours) ?></span>
                </div>
            <?php endif; ?>

            <?php if($friday_hours != ''): ?>
                <div class="hours-wrapper">
                    <span class="work-day"><?php echo esc_html('Friday') ?></span><span class="btm_line"></span><span class="work-hours"><?php echo esc_html($friday_hours) ?></span>
                </div>
            <?php endif; ?>

            <?php if($saturday_hours != ''): ?>
                <div class="hours-wrapper">
                    <span class="work-day"><?php echo esc_html('Saturday') ?></span><span class="btm_line"></span><span class="work-hours"><?php echo esc_html($saturday_hours) ?></span>
                </div>
            <?php endif; ?>

            <?php if($sunday_hours != ''): ?>
                <div class="hours-wrapper">
                    <span class="work-day"><?php echo esc_html('Sunday') ?></span><span class="btm_line"></span><span class="work-hours"><?php echo esc_html($sunday_hours) ?></span>
                </div>
            <?php endif; ?>

        </div>    
        <?php
        echo ale_return( $args[ 'after_widget' ] );
    }
    
    
    function update ( $old_instance , $new_instance) {
        $new_instance[ 'title' ]        = strip_tags( $old_instance[ 'title' ] );
        $new_instance['monday_hours'] = ( $old_instance['monday_hours'] );
        $new_instance['tuesday_hours'] = ( $old_instance['tuesday_hours'] );
        $new_instance['wednesday_hours'] = ( $old_instance['wednesday_hours'] );
        $new_instance['thursday_hours'] = ( $old_instance['thursday_hours'] );
        $new_instance['friday_hours'] = ( $old_instance['friday_hours'] );
        $new_instance['saturday_hours'] = ( $old_instance['saturday_hours'] );
        $new_instance['sunday_hours'] = ( $old_instance['sunday_hours'] );

        return $new_instance;
    	
    }
    
    function form($instance){
    	if(isset($instance['title'])){
            $title = $instance['title'];
        }
        else{
            $title = esc_html__( 'Working Hours', 'elli' );
        }

        $monday_hours        = '';
        $tuesday_hours       = '';
        $wednesday_hours     = '';
        $thursday_hours      = '';
        $friday_hours        = '';
        $saturday_hours      = '';
        $sunday_hours        = '';

        if(isset($instance['monday_hours'])){
            $monday_hours = $instance['monday_hours'];
        }
        if(isset($instance['tuesday_hours'])){
            $tuesday_hours = $instance['tuesday_hours'];
        }
        if(isset($instance['wednesday_hours'])){
            $wednesday_hours = $instance['wednesday_hours'];
        }
        if(isset($instance['thursday_hours'])){
            $thursday_hours = $instance['thursday_hours'];
        }
        if(isset($instance['friday_hours'])){
            $friday_hours = $instance['friday_hours'];
        }
        if(isset($instance['saturday_hours'])){
            $saturday_hours = $instance['saturday_hours'];
        }
        if(isset($instance['sunday_hours'])){
            $sunday_hours = $instance['sunday_hours'];
        }

        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e( 'Title:', 'elli' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'monday_hours' )); ?>"><?php esc_html_e( 'Monday Hours:' , 'elli' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'monday_hours' )); ?>" 
                       name="<?php echo esc_attr($this->get_field_name( 'monday_hours' )); ?>" type="text" 
                       value="<?php echo esc_attr( $monday_hours ); ?>" />
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'tuesday_hours' )); ?>"><?php esc_html_e( 'Tuesday Hours:' , 'elli' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'tuesday_hours' )); ?>" 
                       name="<?php echo esc_attr($this->get_field_name( 'tuesday_hours' )); ?>" type="text" 
                       value="<?php echo esc_attr( $tuesday_hours ); ?>" />
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'wednesday_hours' )); ?>"><?php esc_html_e( 'Wednesday Hours:' , 'elli' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'wednesday_hours' )); ?>" 
                       name="<?php echo esc_attr($this->get_field_name( 'wednesday_hours' )); ?>" type="text" 
                       value="<?php echo esc_attr( $wednesday_hours ); ?>" />
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'thursday_hours' )); ?>"><?php esc_html_e( 'Thursday Hours:' , 'elli' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'thursday_hours' )); ?>" 
                       name="<?php echo esc_attr($this->get_field_name( 'thursday_hours' )); ?>" type="text" 
                       value="<?php echo esc_attr( $thursday_hours ); ?>" />
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'friday_hours' )); ?>"><?php esc_html_e( 'Friday Hours:' , 'elli' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'friday_hours' )); ?>" 
                       name="<?php echo esc_attr($this->get_field_name( 'friday_hours' )); ?>" type="text" 
                       value="<?php echo esc_attr( $friday_hours ); ?>" />
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'saturday_hours' )); ?>"><?php esc_html_e( 'Saturday Hours:' , 'elli' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'saturday_hours' )); ?>" 
                       name="<?php echo esc_attr($this->get_field_name( 'saturday_hours' )); ?>" type="text" 
                       value="<?php echo esc_attr( $saturday_hours ); ?>" />
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'sunday_hours' )); ?>"><?php esc_html_e( 'Sunday Hours:' , 'elli' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'sunday_hours' )); ?>" 
                       name="<?php echo esc_attr($this->get_field_name( 'sunday_hours' )); ?>" type="text" 
                       value="<?php echo esc_attr( $sunday_hours ); ?>" />
        </p>
        
    <?php
    }
}
