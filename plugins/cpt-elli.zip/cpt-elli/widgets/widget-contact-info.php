<?php
/**
 * Blog Widget 
 */
class Aletheme_Contact_Info_Widget extends WP_Widget 
{
	/**
	 * General Setup 
	 */
	public function __construct() {
	
		/* Widget settings. */
		$widget_ops = array(
			'classname' => 'ale_contact_info_widget', 
			'description' => esc_html__('A widget that displays your contact info. (Address/Email/Phone)', 'elli')
		);

		/* Create the widget. */
		parent::__construct( 'ale_contact_info_widget', esc_html__('Elli Contact Info', 'elli'), $widget_ops);
	}

	/**
	 * Display Widget
	 * @param array $args
	 * @param array $instance 
	 */
	public function widget( $args, $instance ) 
	{
		extract( $args );
		
		$title = apply_filters('widget_title', $instance['title'] );

		/* Our variables from the widget settings. */
		$address = $instance['address'];
		$address2 = $instance['address2'];
		$email = $instance['email'];
		$email2 = $instance['email2'];
		$phone = $instance['phone'];
		$phone2 = $instance['phone2'];


		/* Before widget (defined by themes). */
		echo ale_wp_kses($before_widget);

		// Display Widget
		?> 
        <?php /* Display the widget title if one was input (before and after defined by themes). */
				if ( $title )
					echo ale_wp_kses($before_title) . esc_attr($title) . ale_wp_kses($after_title);
				?>
			<div class="aletheme-contact-info-widget">
				<?php if($address): ?>
					<p><i class="icon_map_alt"></i><?php echo esc_attr($address, 'elli'); ?></p>
				<?php endif; ?>
				<?php if($address2): ?>
					<p><i class="icon_map_alt"></i><?php echo esc_attr($address2, 'elli'); ?></p>
				<?php endif; ?>
				<?php if($email): ?>
					<p><i class="icon_mail_alt"></i><?php echo esc_attr($email, 'elli'); ?></p>
				<?php endif; ?>
				<?php if($email2): ?>
					<p><i class="icon_mail_alt"></i><?php echo esc_attr($email2, 'elli'); ?></p>
				<?php endif; ?>
				<?php if($phone): ?>
					<p><i class="ti-mobile"></i><?php echo esc_attr($phone, 'elli'); ?></p>
				<?php endif; ?>
				<?php if($phone2): ?>
					<p><i class="ti-mobile"></i><?php echo esc_attr($phone2, 'elli'); ?></p>
				<?php endif; ?>
			</div>
		
		<?php

		/* After widget (defined by themes). */
		echo ale_wp_kses($after_widget);
	}

	/**
	 * Update Widget
	 * @param array $new_instance
	 * @param array $old_instance
	 * @return array 
	 */
	public function update( $new_instance, $old_instance ) 
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['address'] = strip_tags( $new_instance['address'] );
		$instance['address2'] = strip_tags( $new_instance['address2'] );
		$instance['email'] = strip_tags( $new_instance['email'] );
		$instance['email2'] = strip_tags( $new_instance['email2'] );
		$instance['phone'] = strip_tags( $new_instance['phone'] );
		$instance['phone2'] = strip_tags( $new_instance['phone2'] );

		return $instance;
	}
	
	/**
	 * Widget Settings
	 * @param array $instance 
	 */
	public function form( $instance ) 
	{
		//default widget settings.
		$instance = wp_parse_args( (array) $instance );

		$ale_title = '';
		$ale_address = '';
		$ale_address2 = '';
		$ale_email = '';
		$ale_email2 = '';
		$ale_phone = '';
		$ale_phone2 = '';

		if ( isset( $instance[ 'title' ] ) ) {
			$ale_title = $instance[ 'title' ];
		}

		if ( isset( $instance[ 'address' ] ) ) {
			$ale_address = $instance[ 'address' ];
		}

		if ( isset( $instance[ 'address2' ] ) ) {
			$ale_address2 = $instance[ 'address2' ];
		}

		if ( isset( $instance[ 'email' ] ) ) {
			$ale_email = $instance[ 'email' ];
		}

		if ( isset( $instance[ 'email2' ] ) ) {
			$ale_email2 = $instance[ 'email2' ];
		}

		if ( isset( $instance[ 'phone' ] ) ) {
			$ale_phone = $instance[ 'phone' ];
		}

		if ( isset( $instance[ 'phone2' ] ) ) {
			$ale_phone2 = $instance[ 'phone2' ];
		}


		 ?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e('Title:', 'elli') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" value="<?php echo esc_attr($ale_title, 'elli'); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'address' )); ?>"><?php esc_html_e('Address:', 'elli') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'address' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'address' )); ?>" value="<?php echo esc_attr($ale_address, 'elli'); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'address2' )); ?>"><?php esc_html_e('Address 2:', 'elli') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'address2' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'address2' )); ?>" value="<?php echo esc_attr($ale_address2, 'elli'); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'email' )); ?>"><?php esc_html_e('Email:', 'elli') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'email' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'email' )); ?>" value="<?php echo esc_attr($ale_email, 'elli'); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'email2' )); ?>"><?php esc_html_e('Email 2:', 'elli') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'email2' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'email2' )); ?>" value="<?php echo esc_attr($ale_email2, 'elli'); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'phone' )); ?>"><?php esc_html_e('Phone:', 'elli') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'phone' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'phone' )); ?>" value="<?php echo esc_attr($ale_phone, 'elli') ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'phone2' )); ?>"><?php esc_html_e('Phone 2:', 'elli') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'phone2' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'phone2' )); ?>" value="<?php echo esc_attr($ale_phone2, 'elli'); ?>" />
		</p>
	<?php
	}
}