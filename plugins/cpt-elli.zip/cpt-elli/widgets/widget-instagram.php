<?php
/**
 * Blog Widget 
 */
class Aletheme_Instagram_Widget extends WP_Widget 
{
	/**
	 * General Setup 
	 */
	public function __construct() {
	
		/* Widget settings. */
		$widget_ops = array(
			'classname' => 'ale_instagram_widget', 
			'description' => esc_html__('A widget that displays instagram photo.', 'elli')
		);

		/* Widget control settings. */

		/* Create the widget. */
		parent::__construct( 'ale_instagram_widget', esc_html__('Elli Instagram Feed', 'elli'), $widget_ops);
	}

	/**
	 * Display Widget
	 * @param array $args
	 * @param array $instance 
	 */
	public function widget( $args, $instance ) 
	{
		extract( $args );
		
		$title = apply_filters('widget_title', $instance['title'] );

		/* Our variables from the widget settings. */
		$token = $instance['token'];
		$number = $instance['number'];
		$columns = $instance['columns'];

		/* Before widget (defined by themes). */
		echo ale_wp_kses($before_widget);

		// Display Widget
		?> 
        <?php /* Display the widget title if one was input (before and after defined by themes). */
				if ( $title )
					echo ale_wp_kses($before_title) . esc_attr($title) . ale_wp_kses($after_title); ?>
										
					<?php if(!empty($token)) : wp_enqueue_script( 'ale-instafeed-widget' );
			              wp_localize_script( 'ale-instafeed-widget', 'ale_instafeed_wdt', array(
			                'token' => $token,
			              ));  

			            endif; ?>
						<div class="ale-instafeed-wdt-wrapper" data-cols="<?php echo esc_attr($columns, 'elli') ?>" data-num="<?php echo esc_attr($number, 'elli') ?>">
							<ul class="ale_instagramfeed_widget"></ul>
						</div>

			        <?php
			       

		/* After widget (defined by themes). */
		echo ale_wp_kses($after_widget);
	}

	/**
	 * Update Widget
	 * @param array $new_instance
	 * @param array $old_instance
	 * @return array 
	 */
	public function update( $new_instance, $old_instance ) 
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['token'] = strip_tags( $new_instance['token'] );
		$instance['number'] = strip_tags( $new_instance['number'] );
		$instance['columns'] = strip_tags( $new_instance['columns'] );

		return $instance;
	}
	
	/**
	 * Widget Settings
	 * @param array $instance 
	 */
	public function form( $instance ) 
	{
		//default widget settings.
		$instance = wp_parse_args( (array) $instance);
		$ale_title = '';
		$ale_token = '';
		$ale_number = '';
		$ale_columns = '';

		if ( isset( $instance[ 'title' ] ) ) {
			$ale_title = $instance[ 'title' ];
		}

		if ( isset( $instance[ 'token' ] ) ) {
			$ale_token = $instance[ 'token' ];
		}

		if ( isset( $instance[ 'number' ] ) ) {
			$ale_number = $instance[ 'number' ];
		}

		if ( isset( $instance[ 'columns' ] ) ) {
			$ale_columns = $instance[ 'columns' ];
		}

		 ?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e('Title:', 'elli') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" value="<?php echo esc_attr($ale_title, 'elli'); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'token' )); ?>"><?php esc_html_e('Instagram access token:', 'elli') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'token' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'token' )); ?>" value="<?php echo esc_attr($ale_token, 'elli'); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'number' )); ?>"><?php esc_html_e('Number of photos:', 'elli') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'number' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'number' )); ?>" value="<?php echo esc_attr($ale_number, 'elli'); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'columns' )); ?>"><?php esc_html_e('Number of columns:', 'elli') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'columns' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'columns' )); ?>" value="<?php echo esc_attr($ale_columns, 'elli'); ?>" />
		</p>
	<?php
	}
}