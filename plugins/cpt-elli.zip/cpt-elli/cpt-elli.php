<?php
/**
 * Plugin Name: Elli Core
 * Plugin URI: http://pixrow.co
 * Description: A plugin that will init all necessary modules for Elli Theme.
 * Version: 1.0
 * Author: Pixrow Design / PIXROW.CO
 * Author URI: http://pixrow.co
 * License: GPL v2
 */

define( 'ELLI_CORE_PLUGIN', __FILE__ );
define( 'ELLI_CORE_PLUGIN_DIR', untrailingslashit( dirname( ELLI_CORE_PLUGIN ) ) );
define( 'ELLI_CORE_PLUGIN_NAME', 'elli_core' );


//Functions
require_once ('functions/google_maps.php');

//Metaboxes
require_once ('metaboxes/gallery-meta.php');
require_once ('metaboxes/metaboxes.php');
require_once ('media/media.php');

//Widgets
require_once ('widgets/widget-latestposts.php');
require_once ('widgets/widget-working-hours.php');
require_once ('widgets/widget-social.php');
require_once ('widgets/widget-spacer.php');
require_once ('widgets/widget-contact-info.php');
require_once ('widgets/widget-instagram.php');
require_once ('widgets/widgets.php');


/**
* Remove Woocommerce Select2 - Woocommerce 3.2.1+
*/

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
    
    function alewoo_dequeue_select2() {
        if ( class_exists( 'woocommerce' ) ) {
            wp_dequeue_style( 'select2' );
            wp_deregister_style( 'select2' );

            wp_dequeue_script( 'selectWoo');
            wp_deregister_script('selectWoo');
        } 
    }   

    //Disable Select2 from cat widget
    add_action( 'wp_enqueue_scripts', 'alewoo_dequeue_select2', 100 );
}


/**
 * Add Needed Post Types
 */
function ale_init_post_types() {
    if (function_exists('aletheme_get_post_types')) {
        foreach (aletheme_get_post_types() as $type => $options) {
            ale_add_post_type($type, $options['config'], $options['singular'], $options['multiple']);
        }
    }
}
add_action('init', 'ale_init_post_types');

/**
 * Add Needed Taxonomies
 */
function ale_init_taxonomies() {
    if (function_exists('aletheme_get_taxonomies')) {
        foreach (aletheme_get_taxonomies() as $type => $options) {
            ale_add_taxonomy($type, $options['for'], $options['config'], $options['singular'], $options['multiple']);
        }
    }
}
add_action('init', 'ale_init_taxonomies');


/**
 * Register Post Type Wrapper
 * @param string $name
 * @param array $config
 * @param string $singular
 * @param string $multiple
 */
function ale_add_post_type($name, $config, $singular = 'Entry', $multiple = 'Entries') {
    if (!isset($config['labels'])) {
        $config['labels'] = array(
            'name' => $multiple,
            'singular_name' => $singular,
            'not_found'=> 'No ' . $multiple . ' Found',
            'not_found_in_trash'=> 'No ' . $multiple . ' found in Trash',
            'edit_item' => 'Edit ', $singular,
            'search_items' => 'Search ' . $multiple,
            'view_item' => 'View ', $singular,
            'new_item' => 'New ' . $singular,
            'add_new' => 'Add New',
            'add_new_item' => 'Add New ' . $singular,
        );
    }

    register_post_type($name, $config);
}

/**
 * Register taxonomy wrapper
 * @param string $name
 * @param mixed $object_type
 * @param array $config
 * @param string $singular
 * @param string $multiple
 */
function ale_add_taxonomy($name, $object_type, $config, $singular = 'Entry', $multiple = 'Entries') {

    if (!isset($config['labels'])) {
        $config['labels'] = array(
            'name' => $multiple,
            'singular_name' => $singular,
            'search_items' =>  'Search ' . $multiple,
            'all_items' => 'All ' . $multiple,
            'parent_item' => 'Parent ' . $singular,
            'parent_item_colon' => 'Parent ' . $singular . ':',
            'edit_item' => 'Edit ' . $singular,
            'update_item' => 'Update ' . $singular,
            'add_new_item' => 'Add New ' . $singular,
            'new_item_name' => 'New ' . $singular . ' Name',
            'menu_name' => $singular,
        );
    }

    register_taxonomy($name, $object_type, $config);
}

/**
 * Sets up a custom post type to attach image to.  This allows us to have
 * individual galleries for different uploaders.
 */

if ( ! function_exists( 'optionsframework_mlu_init' ) ) {
    function optionsframework_mlu_init () {
        register_post_type( 'optionsframework', array(
            'labels' => array(
                'name' => __( 'Theme Options Media', 'options_framework_theme' ),
            ),
            'public' => true,
            'show_ui' => false,
            'capability_type' => 'post',
            'hierarchical' => false,
            'rewrite' => false,
            'supports' => array( 'title', 'editor' ),
            'query_var' => false,
            'can_export' => true,
            'show_in_nav_menus' => false,
            'public' => false
        ) );
    }
}

/**
 * Add post types that are used in the theme
 *
 * @return array
 */
function aletheme_get_post_types() {
    return array(
        'projects' => array(
            'config' => array(
                'public' => true,
                'menu_position' => 20,
                'has_archive'   => true,
                'supports'=> array(
                    'title',
                    'editor',
                    'thumbnail',
                ),
                'show_in_nav_menus'=> true,
            ),
            'singular' => 'Project',
            'multiple' => 'Projects',
        ),

        'restaurant-menu' => array(
            'config' => array(
                'public' => true,
                'menu_position' => 20,
                'has_archive'   => true,
                'supports'=> array(
                    'title',
                    'editor',
                ),
                'show_in_nav_menus'=> true,
            ),
            'singular' => 'Restaurant Menu',
            'multiple' => 'Restaurant Menu',
        ),
    );
}



/**
 * Add taxonomies that are used in theme
 *
 * @return array
 */
function aletheme_get_taxonomies() {
    return array(
        'project-category'    => array(
            'for'        => array('projects'),
            'config'    => array(
                'sort'        => true,
                'args'        => array('orderby' => 'term_order'),
                'hierarchical' => true,
            ),
            'singular'    => 'Category',
            'multiple'    => 'Categories',
        ),

        'restaurant-menu-category'    => array(
            'for'        => array('restaurant-menu'),
            'config'    => array(
                'sort'        => true,
                'args'        => array('orderby' => 'term_order'),
                'hierarchical' => true,
            ),
            'singular'    => 'Category',
            'multiple'    => 'Categories',
        ),
    );
}

/**
 * Widget Scripts
 */

function ale_add_widget_scripts() {
    wp_register_script( 'ale-instafeed-widget',plugin_dir_url(__FILE__ ) . 'assets/js/jquery.insta-widget.js', array( 'jquery' ), ALETHEME_THEME_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'ale_add_widget_scripts', 10 );


/**
 * Add Aletheme Demo Istall
 */
function ale_demo_add_admin_menu() {
    //Demos Install Page
    function ale_theme_demos() {
        require_once ELLI_CORE_PLUGIN_DIR . '/demo-import/ale_view_demoinstall.php';
    }

    add_theme_page( esc_html__('Demo Install', "cpt-elli"), esc_html__('Demo Install', "cpt-elli"), 'edit_theme_options', 'aletheme_theme_demos','ale_theme_demos');
}
add_action('admin_menu', 'ale_demo_add_admin_menu', 1);

require_once ( ELLI_CORE_PLUGIN_DIR . '/demo-import/demos.php' );

function ale_add_demo_scripts($hook) {
    //Add scripts for Demo Import Page
    if (in_array($hook, array('appearance_page_aletheme_theme_demos'))) {
        wp_enqueue_style('font-awesome');

        wp_enqueue_script( 'ale-demos', plugin_dir_url(__FILE__ ) . 'demo-import/demos.js', array( 'jquery') );
        wp_enqueue_script( 'aletheme-shuffle', plugin_dir_url(__FILE__ ) . 'demo-import/shuffle.min.js', array( 'jquery') );
        wp_enqueue_script( 'aletheme-demo-items', plugin_dir_url(__FILE__ ) . 'demo-import/demo_items.js', array( 'jquery') );

        //Variables for Demo Import JS
        wp_localize_script( 'ale-demos', ' ale_demo_strings', array(
            'installingPlugin' => esc_html__( 'Installing plugin', "cpt-elli" ),
            'activatingPlugin' => esc_html__( 'Activating plugin', "cpt-elli" ),
            'tryAgain' => esc_html__('Try again', "cpt-elli"),
            'aleWpAdminImportNonce' => wp_create_nonce('ale-demo-install'),
            'ale_ajax_url' => admin_url('/admin-ajax.php?ale_theme_name=' . ELLI_CORE_PLUGIN_NAME. '&v=' . ALETHEME_THEME_VERSION ),
            'plugin_failed_activation' => esc_html__( 'Failed to activate.', "cpt-elli" ),
            'plugin_active' => esc_html__( 'Active', "cpt-elli" ),
            'plugin_failed_activation_retry' => esc_html__( 'Failed.', "cpt-elli" ),
            'plugin_failed_activation_memory' => esc_html__( 'The plugin failed to activate. Please try to increase the memory_limit on your server.', "cpt-elli" ),
            'content_importing_error' => esc_html__( 'There was a problem during the importing process resulting in the following error from your server:', "cpt-elli" ),
            'required_plugins' => esc_html__('Install required plugins first.', "cpt-elli"),
        ) );
    }
}
add_action( 'admin_enqueue_scripts', 'ale_add_demo_scripts', 10 );


add_action('wp_ajax_nopriv_post-like', 'post_like');
add_action('wp_ajax_post-like', 'post_like');


function post_like()
{
    // Check for nonce security
    $nonce = $_POST['nonce'];
  
    if ( ! wp_verify_nonce( $nonce, 'ajax-nonce' ) )
        die ( 'Busted!');
     
    if(isset($_POST['post_like']))
    {
        // Retrieve user IP address
        $ip = $_SERVER['REMOTE_ADDR'];
        $post_id = $_POST['post_id'];
         
        // Get voters'IPs for the current post
        $meta_IP = get_post_meta($post_id, "voted_IP");
        $voted_IP = $meta_IP[0];
 
        if(!is_array($voted_IP))
            $voted_IP = array();
         
        // Get votes count for the current post
        $meta_count = get_post_meta($post_id, "votes_count", true);
 
        // Use has already voted ?
        if(!hasAlreadyVoted($post_id))
        {
            $voted_IP[$ip] = time();
 
            // Save IP and increase votes count
            update_post_meta($post_id, "voted_IP", $voted_IP);
            update_post_meta($post_id, "votes_count", ++$meta_count);
             
            // Display count (ie jQuery return value)
            echo esc_html($meta_count, 'elli');
        }
        else
            echo "already";
    }
    exit;
}

$timebeforerevote = 120; // = 2 hours

function hasAlreadyVoted($post_id)
{
    global $timebeforerevote;
 
    // Retrieve post votes IPs
    $meta_IP = get_post_meta($post_id, "voted_IP");
  
    if(!empty($meta_IP)){
        $voted_IP = $meta_IP[0];
    } else {
        $meta_IP[0] = '';
        $voted_IP = $meta_IP[0];
    }
     
    if(!is_array($voted_IP))
        $voted_IP = array();
         
    // Retrieve current user IP
    $ip = $_SERVER['REMOTE_ADDR'];
     
    // If user has already voted
    if(in_array($ip, array_keys($voted_IP)))
    {
        $time = $voted_IP[$ip];
        $now = time();
         
        // Compare between current time and vote time
        if(round(($now - $time) / 60) > $timebeforerevote)
            return false;
             
        return true;
    }
     
    return false;
}

function ale_getPostLikeLink($post_id)
{
    $themename = "elli";
 
    $vote_count = get_post_meta($post_id, "votes_count", true);

    if($vote_count < 1){
        $vote_count = '0';
    }

    $output = '<span class="post-like like-blog-s"><span class="count">'.$vote_count.'</span>';
    if(hasAlreadyVoted($post_id))
        $output .= '<span title="'.__('I like this article', 'elli').'" class="like alreadyvoted"><span class="blog-like icon_heart_alt"></span></span>';
    else
        $output .= '<a class="ale-likes-post-link" href="#" data-post_id="'.$post_id.'"><span title="'.__('I like this article', 'elli').'" class="qtip like"><span class="blog-like icon_heart_alt"></span></span></a>';
    $output .= '</span>';
     
    return $output;
}

