jQuery(function($) {

    /* Get token example - https://instagram.com/oauth/authorize/?client_id=[CLIENT_ID_HERE]&redirect_uri=http://localhost&response_type=token&scope=public_content */
    //9437899247.4e7f960.f6bc4f524c914b35bd073e41265452a7
    "use strict";

    $('.ale-instafeed-wdt-wrapper').each(function(){
        var ale_wr = $(this).find('.ale_instagramfeed_widget');
        var ale_c  = $(this).data('cols');
        var ale_n  = $(this).data('num');
   
    $.ajax({
            type: "GET", 
            url: "//api.instagram.com/v1/users/self/media/recent/?access_token=" + ale_instafeed_wdt.token,
            crossDomain: true,
            data: {access_token: ale_instafeed_wdt.token, count: ale_n },
            success: function(response) {

                $.each(response.data, function(index, obj) {

                    var ale_sz = 100 / ale_c + '%';
                    ale_wr.append("<li class=\"ale-insta-list\"style='flex-basis: " + ale_sz + ";'><a href='" + obj.link + "' target='_blank'><img src=" + obj.images.low_resolution.url + "></a></li>");
                })
            },

            dataType: "jsonp" //set to JSONP, is a callback
        });
   });
});