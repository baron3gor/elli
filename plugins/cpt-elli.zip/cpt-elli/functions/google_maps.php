<?php
/*
* 
* Google Map Shortcodes
* 	
*/ 
if( ! function_exists("ale_google_map") ){
	/**
	 * Google Map Holder Shortcode 
	 * 
	 * @param  array $atts  
	 * @param  string $content  
	 * @return html $google_map
	 */
	function ale_google_map( $atts, $content = null ) { 

	global $ale_map_id, $ale_total_location, $ale_location_count, $ale_locations_output, $ale_zoom, $ale_red_option; 

	extract(shortcode_atts(array(  
		"map_id" => "map-".rand(100000, 1000000),
		"height" => 300,
		"zoom" => 3,
		"class" => "",
		"ellicolor" => ""
	), $atts));

	//fix map id if empty
	$map_id =  empty( $map_id ) ? 'map-'.rand(100000, 1000000) : $map_id ;
	
	//class
	$class = ! empty( $class ) ? ' '. $class : "";

	//load google api
	if(!empty($ale_red_option['google-maps-api'])) :
		$api_key = $ale_red_option['google-maps-api'];
	endif;
	
	if( ! empty( $api_key ) ){
		$googlemaps_url = add_query_arg( 'key', urlencode( $api_key ), "//maps.googleapis.com/maps/api/js" );
		wp_enqueue_script('googlemaps',$googlemaps_url,array(), '1.0.0');
	}else{
		wp_enqueue_script('googlemaps','//maps.googleapis.com/maps/api/js');
	}
	
	//find total location number
	$total_location = substr_count($content,'[location');

	//global values
	$ale_map_id = $map_id;
	$ale_total_location = $total_location;
	$ale_location_count = 0; 
	$ale_locations_output = ""; 
	$ale_zoom = $zoom;
	$ale_map_color = $ellicolor;


	//content
	$content = do_shortcode($content); 
	$markerclr = $ale_red_option['google-maps-marker'];
	$markerstr = $ale_red_option['google-maps-marker-stroke'];
	
	//output
	$google_map = sprintf('<div class="google_map_holder%s" data-height="%s" data-scope="#%s" data-elli="%s" data-marker="%s" data-markerstr="%s">%s</div>',$class, $height, $map_id, $ellicolor, $markerclr, $markerstr, $content); 

	return $google_map;
	}
}


if( ! function_exists("ale_map_location") ){
	/**
	 * Google Map Single Location
	 * 
	 * @param  array $atts  
	 * @param  string $content  
	 * @return html $js_output
	 */
	function ale_map_location( $atts, $content = null ) {
	global $ale_map_id, $ale_total_location, $ale_location_count, $ale_locations_output, $ale_zoom; 



	extract(shortcode_atts(array(  
		"title" => "",
		"lat" => 0,
		"lon" => 0,
	), $atts));

	$ale_location_count++;


	//locations_output
	$new_ale_location = ! empty( $lat ) && ! empty( $lon ) ?  sprintf('["%s", %s, %s, 4,"%s"],', addslashes($title), $lat, $lon, addslashes($content)) : "";	 		

	$ale_locations_output .= preg_replace('~[\r\n\t]+~', '', $new_ale_location );


	if ( $ale_total_location == $ale_location_count) {	 	

		//js script to run
		$js_output = sprintf('

			<div id="%s" class="google_map"></div>
			<script type="text/javascript">
			 /* <![CDATA[ */ 
				// Runs google maps	
					jQuery(function() {
						jQuery("#%s").ale_maps([%s],%s); 
					});
			/* ]]> */	
			</script>

		', $ale_map_id, $ale_map_id, $ale_locations_output,$ale_zoom);

		return $js_output;
	} 
	} 
}

add_shortcode('google_maps', 'ale_google_map');
add_shortcode('location', 'ale_map_location');